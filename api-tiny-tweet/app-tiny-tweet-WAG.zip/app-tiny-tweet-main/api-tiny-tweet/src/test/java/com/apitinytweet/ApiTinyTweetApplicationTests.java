package com.apitinytweet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTinyTweetApplicationTests
{

	@Test
	void contextLoads()
	{
	}

}
