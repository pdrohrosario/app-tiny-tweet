package com.apitinytweet.dto.user;

public record LoginRecord(
	String username,
	String password
)
{
}
