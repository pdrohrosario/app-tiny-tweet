package com.apitinytweet.dto.user;

public record UserRecord(
		Long id,
		String username,
		String password
)
{
}
