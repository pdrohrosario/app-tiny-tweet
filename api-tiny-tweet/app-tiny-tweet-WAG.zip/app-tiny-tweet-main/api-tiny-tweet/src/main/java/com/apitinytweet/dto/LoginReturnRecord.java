package com.apitinytweet.dto;

public record LoginReturnRecord(
		String username,
		Long id,
		String token)
{
}
