# App Tiny Tweet

## Descrição
 - Uma plataforma onde usuários pode criar uma conta, publicar e ver textos.

## Funcionalidades
 - Criar conta
 - Login
 - Criar postagem (titulo e conteúdo)
 - Ver feed (todas as publições de todos os usuários)

## Como rodar
### API Spring boot
 - IDEA: Abra a pasta /api-tiny-tweet no IntelliJ e clique para executar.

### App
 - O app depende da API
 - No android studio, abra a pasta /apptinytweet e execute o projeto.